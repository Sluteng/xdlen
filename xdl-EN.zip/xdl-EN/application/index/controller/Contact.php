<?php
namespace app\index\controller;

use think\Controller;
use think\Loader;

class Contact extends controller
{
    public function contact()
    {   
    require_once('Base.php');
    $abouthResult=$navberModel->where([
            'isdelete'=>0,
            'status'=>1,
            'id'=>6
        ])->limit(1)->select();
    $title= i_array_column($abouthResult,'name');
    $head = reset($title);
    $hewdModel=Loader::model('Head');
    $headResult=$hewdModel->where([
            'isdelete'=>0,
            'status'=>1,
            'title'=>$head
        ])->limit(1)->select();
      if (request()->isPost()){
       $data = input('post.');
       // return json($data);
       $validate = validate('Message');
       if (!$validate->batch()->check($data)) {
         $error = $validate->getError();
         $this->error(implode(',',$error));
       }else{
        $center = model('Message');
        $center->data($data,true);
        $result = $center->allowField(true)->save();
        if ($result) {
        echo "<script>alert('Message submitted successfully');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";exit;
        } else {
         echo "<script>alert('Message submission failed');location.href='".$_SERVER["HTTP_REFERER"]."';</script>";exit;
         }
       }   
    }
    return $this->view->fetch('',[
      'abouthResult'=>$abouthResult,
      'headResult'=>$headResult,
           ]);
    }
}       